# 1224405451089903759
# 50c8b0f8f788e0fac7fb06f355dfd1e7c9688138e9b16bfe358b72d8fdfd7cf6
# MTIyNDQwNTQ1MTA4OTkwMzc1OQ.GLwU1y.aypWz1QZzX8AFr-mdaX8uEXpGkdMjUgIupbX1o token
import discord
import os

from discord import message
from discord import channel
from openai import OpenAI
import openai
client = OpenAI()

OpenAI.api_key= os.getenv("OPENAI_API_KEY")
token = os.environ['SECRET_KEY']
class MyClient(discord.Client):
    async def on_ready(self):
        print('Logged on as', self.user)

    async def on_message(self, message):
        # don't respond to ourselves
        if message.author == self.user:
            return
        if self.user in message.mentions :
            channel=message.channel
            response = openai.completions.create(
              model="gpt-3.5-turbo-instruct-0914",
              prompt="",
              temperature=1,
              max_tokens=256,
              top_p=1,
              frequency_penalty=0,
              presence_penalty=0
            )
            messageToSend=response.choices[0].text
            await channel.send(messageToSend)

intents = discord.Intents.default()
intents.message_content = True
client = MyClient(intents=intents)
client.run(token)